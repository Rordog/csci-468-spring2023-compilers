package edu.montana.csci.csci468.demo;

import org.junit.jupiter.api.Test;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.LinkedList;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class Scratch {

    int add(int i) {
        return i + 13;
    }

    public int intFunc(int i1, int i2) {
        return i1 + i2;
    }

    public static void main(String[] args) {
        for(int x = 0; x < 3; x++){
            var y = x;
            System.out.println(y);
        }
    }
}
